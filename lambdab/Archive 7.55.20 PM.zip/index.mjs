import AWS from "aws-sdk";
const s3 = new AWS.S3();

export const handler = async (event) => {
  /*
    // TODO implement
  const response = {
    statusCode: 200,
    body: JSON.stringify("Hello World!"),
  };
  return response;
  */
  try {
    // Specify the S3 bucket and file key
    const bucketName = "ust-ff-jason";
    const ust1M = "UST_1M.json"; // Replace with your file's path and name
    const ust1Y = "UST_1Y.json";
    const ust2M = "UST_2M.json";
    const ust2Y = "UST_2Y.json";
    const ust3M = "UST_3M.json";
    const ust3Y = "UST_3Y.json";
    const ust4M = "UST_4M.json";
    const ust5Y = "UST_5Y.json";
    const ust6M = "UST_6M.json";
    const ust7Y = "UST_7Y.json";
    const ust10Y = "UST_10Y.json";
    const ust20Y = "UST_20Y.json";
    const ust30Y = "UST_30Y.json";

    // Specify S3 parameters
    const paramsUst1M = { Bucket: bucketName, Key: ust1M };
    const paramsUst1Y = { Bucket: bucketName, Key: ust1Y };
    const paramsUst2M = { Bucket: bucketName, Key: ust2M };
    const paramsUst2Y = { Bucket: bucketName, Key: ust2Y };
    const paramsUst3M = { Bucket: bucketName, Key: ust3M };
    const paramsUst3Y = { Bucket: bucketName, Key: ust3Y };
    const paramsUst4M = { Bucket: bucketName, Key: ust4M };
    const paramsUst5Y = { Bucket: bucketName, Key: ust5Y };
    const paramsUst6M = { Bucket: bucketName, Key: ust6M };
    const paramsUst7Y = { Bucket: bucketName, Key: ust7Y };
    const paramsUst10Y = { Bucket: bucketName, Key: ust10Y };
    const paramsUst20Y = { Bucket: bucketName, Key: ust20Y };
    const paramsUst30Y = { Bucket: bucketName, Key: ust30Y };

    // Read the JSON file from S3
    // Parse the JSON data
    const s3Response1M = await s3.getObject(paramsUst1M).promise();
    const jsondata1M = JSON.parse(s3Response1M.Body.toString("utf-8"));
    const s3Response1Y = await s3.getObject(paramsUst1Y).promise();
    const jsondata1Y = JSON.parse(s3Response1Y.Body.toString("utf-8"));
    const s3Response2M = await s3.getObject(paramsUst2M).promise();
    const jsondata2M = JSON.parse(s3Response2M.Body.toString("utf-8"));
    const s3Response2Y = await s3.getObject(paramsUst2Y).promise();
    const jsondata2Y = JSON.parse(s3Response2Y.Body.toString("utf-8"));
    const s3Response3M = await s3.getObject(paramsUst3M).promise();
    const jsondata3M = JSON.parse(s3Response3M.Body.toString("utf-8"));
    const s3Response3Y = await s3.getObject(paramsUst3Y).promise();
    const jsondata3Y = JSON.parse(s3Response3Y.Body.toString("utf-8"));
    const s3Response4M = await s3.getObject(paramsUst4M).promise();
    const jsondata4M = JSON.parse(s3Response4M.Body.toString("utf-8"));
    const s3Response5Y = await s3.getObject(paramsUst5Y).promise();
    const jsondata5Y = JSON.parse(s3Response5Y.Body.toString("utf-8"));
    const s3Response6M = await s3.getObject(paramsUst6M).promise();
    const jsondata6M = JSON.parse(s3Response6M.Body.toString("utf-8"));
    const s3Response7Y = await s3.getObject(paramsUst7Y).promise();
    const jsondata7Y = JSON.parse(s3Response7Y.Body.toString("utf-8"));
    const s3Response10Y = await s3.getObject(paramsUst10Y).promise();
    const jsondata10Y = JSON.parse(s3Response10Y.Body.toString("utf-8"));
    const s3Response20Y = await s3.getObject(paramsUst20Y).promise();
    const jsondata20Y = JSON.parse(s3Response20Y.Body.toString("utf-8"));
    const s3Response30Y = await s3.getObject(paramsUst30Y).promise();
    const jsonData30Y = JSON.parse(s3Response30Y.Body.toString("utf-8"));

    // Now you can work with the JSON data as needed
    console.log(
      "JSON data:",
      jsondata1M,
      "\n",
      jsondata1Y,
      "\n",
      jsondata2M,
      "\n",
      jsondata2Y,
      "\n",
      jsondata3M,
      "\n",
      jsondata3Y,
      "\n",
      jsondata4M,
      "\n",
      jsondata5Y,
      "\n",
      jsondata6M,
      "\n",
      jsondata7Y,
      "\n",
      jsondata10Y,
      "\n",
      jsondata20Y,
      "\n",
      jsonData30Y
    );
    return {
      statusCode: 200,
      body: "JSON files successfully read from S3",
      yeah: jsonData,
    };
  } catch (error) {
    console.error("Error:", error);
    return {
      statusCode: 500,
      body: "Error reading JSON files from S3",
    };
  }
};
